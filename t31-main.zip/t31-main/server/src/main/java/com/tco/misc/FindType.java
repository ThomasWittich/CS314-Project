package com.tco.misc;

public enum FindType {
    airport,balloonport,heliport,other
}