const serverSettings = {}
export default serverSettings